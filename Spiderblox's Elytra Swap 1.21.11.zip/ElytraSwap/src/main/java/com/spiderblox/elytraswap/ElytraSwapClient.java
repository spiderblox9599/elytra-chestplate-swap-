com.spiderblox.elytraswap.ElytraSwapClient

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class ElytraSwapClient implements ClientModInitializer {

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(
                    Identifier.fromNamespaceAndPath("elytraswap", "main")
            );

    private static KeyMapping swapKey;

    @Override
    public void onInitializeClient() {

        swapKey = KeyBindingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.elytraswap.swap",
                        GLFW.GLFW_KEY_M,
                        CATEGORY
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (swapKey.consumeClick()) {
                if (client.player != null && client.gameMode != null) {
                    swap(client);
                }
            }
        });
    }

    private static void swap(Minecraft client) {
        // 9th hotbar slot
        client.player.getInventory().setSelectedSlot(8);

        // TODO: inventory Elytra swap logic

        // 7th hotbar slot
        client.player.getInventory().setSelectedSlot(6);
    }
}