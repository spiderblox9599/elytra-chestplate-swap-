package com.spiderblox.elytraswap;

import net.fabricmc.api.ModInitializer;

public class ElytraSwap implements ModInitializer {
    @Override
    public void onInitialize() {
    }
}